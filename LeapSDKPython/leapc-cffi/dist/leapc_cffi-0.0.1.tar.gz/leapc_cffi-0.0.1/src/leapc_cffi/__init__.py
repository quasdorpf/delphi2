from ._leapc_cffi import ffi, lib as libleapc
